import { RankingService } from './../../service/ranking.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css'],
  providers:[RankingService]
})
export class MainComponent implements OnInit {
  private ageData:any;
  private heightData:any;
  constructor(private rankingService:RankingService) { 
    this.ageData = rankingService.getAgeRankData(); /* Set Services Age Rank Data */
    this.heightData = rankingService.getHeightRankData(); 
    this.rankingService.rankingServiceEvent.subscribe((result:string) => console.log('Rank Result',result));
  }

  ngOnInit() {
    
  }

  ngOnDestroy() {
    this.rankingService.rankingServiceEvent.unsubscribe();
  }
  



}
