import { RankingService } from './../../service/ranking.service';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-range-slider',
  templateUrl: './range-slider.component.html',
  styleUrls: ['./range-slider.component.css'],
})
export class RangeSliderComponent implements OnInit {
  
  @Input() range:{min:number,max:number}[];
  
  @Input() rank:any;  
  
  private currentRange:any;


  constructor( private rankingService: RankingService) { }

  ngOnInit() {
    
    /* set min range as range default on app initialize */
   this.currentRange = this.range['min'];
    console.log("Slider Range",this.currentRange);

    
    
    /* Emit the range value */
  }

  change(event) {
    this.currentRange = event;
    console.log(this.currentRange);
    this.rankingService.rankingServiceEvent.emit(this.currentRange);
  }
    



}
