import { Injectable, EventEmitter, Output } from '@angular/core';

@Injectable()
export class RankingService {
  private heightRank:{range:{min:number,max:number},rank:{id:number,value:{}}[]};
  private ageRank:{range:{min:number,max:number},rank:{id:number,value:{}}[]}
  
  

  @Output() rankingServiceEvent = new EventEmitter<string>();

  constructor() { }
  
  getAgeRankData(){
    return  this.ageRank = {
        range:{
          min:14,
          max:70
        },
        rank:[{
          id:1,
          value:['17','21']
        },
        {
          id:2,
          value:['22','27']
        },
        {
          id:3,
          value:['28','34']
        },
        {
          id:4,
          value:['35','42']
        },
        {
          id:5,
          value:['42']
        }
        ]
      }    
  }

  getHeightRankData(){
     return this.heightRank = {
        range:{
          min:140,
          max:210
        },
        rank:[
          {
            id:1,
            value:['140','155']
          },
          {
            id:2,
            value:['156','165']
          },
          {
            id:3,
            value:['166','180']
          },
          {
            id:4,
            value:['181','205']
          },
          {
            id:5,
            value:['206']
          }
        ]
      }    
  }
  
  getRank(data:any){
    
    console.log("From Ranking Service",data);
  }


}
